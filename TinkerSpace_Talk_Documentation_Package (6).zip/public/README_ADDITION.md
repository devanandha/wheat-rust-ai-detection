## Talks and community knowledge sharing

- **28 October 2026 — AI Wednesday, TinkerSpace Kochi:** [Beyond Accuracy: What Happens When AI Meets Real-World Data?](talks/2026-10-28-ai-wednesday/README.md) — slides, session summary and photographs covering transfer learning, cross-dataset evaluation and explainability.
