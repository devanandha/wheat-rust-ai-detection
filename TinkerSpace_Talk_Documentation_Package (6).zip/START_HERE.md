# TinkerSpace session documentation

## Public GitHub files

Copy the `talks` folder inside `public` to the root of your existing `wheat-rust-ai-detection` repository. Add the text from `public/README_ADDITION.md` to the repository's main README. Review the changes, then commit and push. No repository files have been changed or published by this package.

The public page includes the selected retouched photographs, notes-free slide PDF, official event listing and LinkedIn recap. The images are described as retouched, and the page makes no audience-size or speaker-selection claim.

## Private records

Keep `private` outside the public repository. It contains the revised evidence draft, source index and reusable checklist. Retain the original correspondence, photos, videos and screenshots alongside it. Review the evidence document before using it in an application.

The event had 22 registrations. Total physical attendance was not formally recorded. The speaker reports that additional people in the shared workspace joined the session. Do not treat the earlier estimate of 12 as a final attendance total.
