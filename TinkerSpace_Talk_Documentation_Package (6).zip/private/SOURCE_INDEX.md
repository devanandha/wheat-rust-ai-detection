# TinkerSpace session source index

- Date: 28 October 2026.
- Title: Beyond Accuracy: What Happens When AI Meets Real-World Data?
- Venue: TinkerSpace Kochi.
- Role: delivered the talk; listed under hosts and identified as organiser in the app. Competitive speaker selection is not documented.
- Official event: https://tinkerhub.org/events/Q2Y0PRTW2U/ai-wednesday
- Public recap, supplied by speaker: https://lnkd.in/p/dsHjJuZT
- Booking email: screenshot image(20261029-092803).png; Muhammed Shan, 23 October 2026.
- Event screenshots: 1000063025.jpg, 1000063026.jpg, 1000063055.jpg.
- Registrations: app final screenshot displays 22. Not a physical attendance record.
- Physical attendance: total not formally recorded; speaker reports additional walk-ins from the shared workspace.
- Original event photos: 1000063136.jpg, 1000063133.jpg, 1000063121.jpg, 1000063115.jpg.
- Short videos: 1000063148.mp4, 1000063142.mp4, 1000063139.mp4, 1000063145.mp4, 1000063103.mp4, 1000063104.mp4.
- Presentation: 37 slides; notes-free copy and exported PDF prepared.
- Selected public images: SS1(1).png, SS2(1).png, SS3(1).png; AI-retouched versions, not used to establish audience totals.
- Outstanding: actual speaking duration; any organiser-confirmed attendance; organiser recap or participant feedback if available; screenshot of the published recap.
