# Session documentation checklist

Use one folder per session: YYYY-MM-DD_organiser_topic.

## Before

- Save speaker arrangements and any documented invitation or selection process.
- Save the official event listing with speaker name, topic, date, venue and URL.
- Record organiser and event contact details privately.

## During

- Keep original photos: speaker with technical slides, wider audience view, participant interaction.
- Keep original video and any recording link.
- Ask for actual check-in or attendance figures where available; distinguish registrations, physical attendance and online views.
- Record your actual speaking duration separately from the advertised event window.

## Within 48 hours

- Save the final slides and export a public PDF without notes.
- Publish a factual recap and preserve its URL and dated screenshot.
- Add a public talk page linking slides, official listing and recording where available.
- Keep private emails and attendee personal information out of public uploads.

## Afterwards

- Retain genuine participant feedback and organiser acknowledgements or reposts.
- Record documented outcomes such as resource use, later invitations or collaboration, with sources.
- Preserve a copy of public pages if they may change.

## Evidence draft

- Explain your role, contribution and relevance with readable supporting records.
- Attribute estimates and identify missing confirmation.
- Use original photographs for the evidence record.
- Verify names, dates, all numbers, captions and URLs.
- Record one achievement with multiple supporting sources; do not count each platform as a separate achievement.
- Recheck application requirements when finalising the application.
